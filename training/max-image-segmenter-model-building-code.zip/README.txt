1. place your training code into this directory 
2. update requirements.txt
3. customize train-max-model.sh

